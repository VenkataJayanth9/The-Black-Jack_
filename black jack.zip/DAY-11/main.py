#In this we are going to create an intresting game called BLACKJACK.

#There are 13 cards of each color and there are 4 different colors in the deck.

#So total no of cards in the deck is 52.

#There are 3 face cars in each category and 10 normal card will be there

#[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
#face cards are KING, QUEEN, JACK.

#The value of each face card is equal to 10.

#--->>> Game Procedure <<<---

# step - 1:
# First we need to select two random cards from the deck to the player and then 2 cards to the computer.

#Step - 2:
#Then we need to ask the user weather he need to draw an extra card from the deck or no.
#Then to the computer also.

#step-3:
#Winner rules:
#1.The sum of the values of the cards should not exceed 21
#2.The person with greaters number will be won and the sum should not exceed 21.